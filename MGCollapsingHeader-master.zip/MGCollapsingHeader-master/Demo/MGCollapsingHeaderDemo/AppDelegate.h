//
//  AppDelegate.h
//  MGCollapsingHeaderDemo
//
//  Created by Matthew Gardner on 12/16/15.
//  Copyright © 2015 Matthew Gardner. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

